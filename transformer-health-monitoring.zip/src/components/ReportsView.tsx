import React, { useState, useEffect } from 'react';
import { getPredictionHistoryApi, generatePdfReportApi } from '../services/api';
import { PredictionHistoryRecord } from '../types';
import { HealthBadge } from './HealthBadge';
import { FileText, Download, Clock, RefreshCw } from 'lucide-react';

export const ReportsView: React.FC = () => {
  const [history, setHistory] = useState<PredictionHistoryRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const records = await getPredictionHistoryApi();
      setHistory(records);
    } catch (err) {
      console.error('History fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleDownloadReport = async (record: PredictionHistoryRecord) => {
    setDownloadingId(record.id);
    try {
      const res = await generatePdfReportApi(record.input_data, {
        transformer_health: record.predicted_status,
        prediction_confidence: record.confidence,
        risk_score: record.risk_score,
        recommendation: record.recommendation,
        alerts: []
      });
      if (res.download_url) {
        window.location.href = res.download_url;
      }
    } catch (err) {
      console.error('Download report error:', err);
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Diagnostic & Maintenance Reports</h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Generate and download industrial PDF maintenance assessment reports for transformer units.
          </p>
        </div>

        <button
          onClick={fetchHistory}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-xs rounded-xl transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Logs
        </button>
      </div>

      {/* History table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            Recent Assessment History ({history.length} records)
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold uppercase text-[10px]">
              <tr>
                <th className="p-3">Transformer ID</th>
                <th className="p-3">Predicted Health</th>
                <th className="p-3">Confidence</th>
                <th className="p-3">Risk Score</th>
                <th className="p-3">Action Recommendation</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3 text-right">PDF Report</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {history.map((rec) => (
                <tr key={rec.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-blue-600 dark:text-blue-400">{rec.transformer_id}</td>
                  <td className="p-3">
                    <HealthBadge status={rec.predicted_status} />
                  </td>
                  <td className="p-3 font-semibold">{rec.confidence}%</td>
                  <td className="p-3 font-semibold text-rose-600 dark:text-rose-400">{rec.risk_score}/100</td>
                  <td className="p-3 max-w-xs truncate">{rec.recommendation}</td>
                  <td className="p-3 text-slate-400">{rec.timestamp}</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={() => handleDownloadReport(rec)}
                      disabled={downloadingId === rec.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50"
                    >
                      <Download className="w-3.5 h-3.5" />
                      {downloadingId === rec.id ? 'Generating...' : 'PDF'}
                    </button>
                  </td>
                </tr>
              ))}
              {!history.length && (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-slate-400">
                    No prediction log history recorded yet. Run a prediction on the "Predict Health" page.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
