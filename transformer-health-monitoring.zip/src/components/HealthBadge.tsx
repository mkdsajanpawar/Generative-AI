import React from 'react';
import { HealthStatus } from '../types';
import { CheckCircle2, AlertTriangle, AlertOctagon } from 'lucide-react';

export const HealthBadge: React.FC<{ status?: HealthStatus | string; className?: string }> = ({ status, className = '' }) => {
  const norm = (status || 'Healthy').toLowerCase();

  if (norm === 'healthy') {
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 ${className}`}>
        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
        Healthy
      </span>
    );
  }

  if (norm === 'warning') {
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20 ${className}`}>
        <AlertTriangle className="w-3 h-3 text-amber-400" />
        Warning
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-rose-500/10 text-rose-400 border border-rose-500/20 ${className}`}>
      <AlertOctagon className="w-3 h-3 text-rose-400" />
      Critical
    </span>
  );
};

export const AlertBadge: React.FC<{ type: string; message: string }> = ({ type, message }) => {
  return (
    <div className="flex items-start gap-2.5 p-3 rounded bg-rose-950/40 border border-rose-800/60 text-rose-200 text-xs font-mono">
      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
      <div>
        <div className="font-bold text-rose-300 uppercase tracking-tight">{type}</div>
        <div className="text-rose-400/90 text-[11px] mt-0.5">{message}</div>
      </div>
    </div>
  );
};
