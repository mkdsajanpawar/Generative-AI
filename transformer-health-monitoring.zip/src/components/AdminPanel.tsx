import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { uploadDatasetFile, retrainModelApi } from '../services/api';
import { ModelStats } from '../types';
import { Settings, Upload, RefreshCw, Download, Award, CheckCircle2, ShieldAlert } from 'lucide-react';

interface AdminPanelProps {
  modelStats: ModelStats | null;
  onModelRetrained: () => void;
  onOpenLogin: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ modelStats, onModelRetrained, onOpenLogin }) => {
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [retraining, setRetraining] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!user) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center space-y-4 max-w-lg mx-auto my-12 shadow-md">
        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Admin Access Restricted</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          The Admin Panel allows uploading custom datasets, triggering machine learning retraining, and inspecting algorithm confusion matrices. Please log in to proceed.
        </p>
        <button
          onClick={onOpenLogin}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-md transition-colors"
        >
          Admin Login
        </button>
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    setMsg(null);

    try {
      const res = await uploadDatasetFile(file);
      setMsg({ type: 'success', text: res.message || 'Dataset uploaded and model retrained successfully!' });
      setFile(null);
      onModelRetrained();
    } catch (err: any) {
      setMsg({ type: 'error', text: err.response?.data?.error || 'Failed to upload dataset.' });
    } finally {
      setUploading(false);
    }
  };

  const handleRetrain = async () => {
    setRetraining(true);
    setMsg(null);
    try {
      const res = await retrainModelApi();
      setMsg({ type: 'success', text: `Model retrained successfully! Best Model: ${res.summary?.best_model} (${(res.summary?.best_accuracy * 100).toFixed(1)}% Accuracy)` });
      onModelRetrained();
    } catch (err: any) {
      setMsg({ type: 'error', text: err.response?.data?.error || 'Retraining failed.' });
    } finally {
      setRetraining(false);
    }
  };

  const handleDownloadDataset = () => {
    window.location.href = '/download?file=dataset.csv';
  };

  return (
    <div className="space-y-6">
      {/* Admin Title */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Admin Control & ML Lifecycle</h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Logged in as <span className="font-semibold text-slate-800 dark:text-slate-200">{user.username}</span> ({user.role})
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadDataset}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-xs rounded-xl transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download Dataset CSV
          </button>
          <button
            onClick={handleRetrain}
            disabled={retraining}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${retraining ? 'animate-spin' : ''}`} />
            {retraining ? 'Retraining...' : 'Retrain All Algorithms'}
          </button>
        </div>
      </div>

      {msg && (
        <div className={`p-4 rounded-xl text-xs font-semibold flex items-center gap-2 ${
          msg.type === 'success'
            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
            : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
        }`}>
          {msg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <ShieldAlert className="w-4 h-4 text-rose-600" />}
          {msg.text}
        </div>
      )}

      {/* Dataset Upload Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Upload New CSV Dataset</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Replace current transformer telemetry records and automatically retrain classifier algorithms.
        </p>

        <form onSubmit={handleUpload} className="flex flex-col sm:flex-row items-center gap-3">
          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            className="block w-full text-xs text-slate-500 dark:text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 dark:file:bg-blue-950 dark:file:text-blue-300 hover:file:bg-blue-100"
          />
          <button
            type="submit"
            disabled={!file || uploading}
            className="w-full sm:w-auto px-5 py-2 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 text-white dark:text-slate-900 font-semibold text-xs rounded-xl shadow-sm transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5 shrink-0"
          >
            <Upload className="w-4 h-4" />
            {uploading ? 'Uploading & Training...' : 'Upload Dataset'}
          </button>
        </form>
      </div>

      {/* Model Performance Comparison Matrix */}
      {modelStats && modelStats.models_comparison && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                Algorithm Evaluation & Metrics Comparison
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Selected Model: <span className="font-bold text-blue-600 dark:text-blue-400">{modelStats.best_model}</span> (Accuracy: {(modelStats.best_accuracy * 100).toFixed(1)}%)
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(modelStats.models_comparison).map(([name, m]) => {
              const metrics = m as import('../types').ModelComparison;
              const isBest = name === modelStats.best_model;
              return (
                <div
                  key={name}
                  className={`p-4 rounded-xl border transition-all ${
                    isBest
                      ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-300 dark:border-blue-700 shadow-md'
                      : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">{name}</span>
                    {isBest && (
                      <span className="px-2 py-0.5 text-[10px] font-extrabold bg-blue-600 text-white rounded-full">
                        Best Accuracy
                      </span>
                    )}
                  </div>
                  <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
                    <div className="flex justify-between">
                      <span>Accuracy:</span>
                      <span className="font-semibold">{((metrics.accuracy || 0) * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Precision:</span>
                      <span className="font-semibold">{((metrics.precision || 0) * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Recall:</span>
                      <span className="font-semibold">{((metrics.recall || 0) * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>F1 Score:</span>
                      <span className="font-semibold">{((metrics.f1_score || 0) * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
