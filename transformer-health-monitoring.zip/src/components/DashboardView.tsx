import React from 'react';
import { DashboardData } from '../types';
import { GaugeMeter } from './GaugeMeter';
import { ChartsSection } from './ChartsSection';
import { Activity, Thermometer, Droplets, Flame, Vibrate, ShieldAlert, CheckCircle, Zap, AlertOctagon, Bell } from 'lucide-react';

interface DashboardViewProps {
  data: DashboardData | null;
  loading: boolean;
  onRefresh: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ data, loading }) => {
  if (loading || !data || !data.metrics) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] gap-3">
        <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs text-slate-400 font-mono">INITIALIZING TELEMETRY & ML MODELS...</p>
      </div>
    );
  }

  const { metrics, charts } = data;

  return (
    <div className="space-y-6 text-slate-200">
      {/* 4 High-Density KPI Header Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* TOTAL ASSETS */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-mono font-bold uppercase tracking-wider">TOTAL ASSETS</span>
            <Activity className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-slate-100 my-2">{metrics.total_transformers}</div>
          <div className="text-[10px] text-emerald-400 font-mono">+100% Active Fleet Coverage</div>
        </div>

        {/* HEALTHY */}
        <div className="bg-slate-900/60 border border-slate-800 border-l-4 border-l-emerald-500 rounded-lg p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-mono font-bold uppercase tracking-wider">HEALTHY</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-bold font-mono text-emerald-400 my-2">{metrics.healthy}</div>
          <div className="text-[10px] text-slate-400 font-mono">
            {((metrics.healthy / metrics.total_transformers) * 100).toFixed(1)}% Optimal Operational State
          </div>
        </div>

        {/* WARNING */}
        <div className="bg-slate-900/60 border border-slate-800 border-l-4 border-l-amber-500 rounded-lg p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-mono font-bold uppercase tracking-wider">WARNING</span>
            <ShieldAlert className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-bold font-mono text-amber-500 my-2">{metrics.warning}</div>
          <div className="text-[10px] text-amber-300 font-mono">Inspection Required</div>
        </div>

        {/* CRITICAL */}
        <div className="bg-slate-900/60 border border-slate-800 border-l-4 border-l-rose-500 rounded-lg p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-mono font-bold uppercase tracking-wider">CRITICAL</span>
            <AlertOctagon className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-3xl font-bold font-mono text-rose-500 my-2">{metrics.critical}</div>
          <div className="text-[10px] text-rose-400 font-mono uppercase font-bold">URGENT ATTENTION</div>
        </div>
      </div>

      {/* Operational Overview & Active Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Fleet Matrix & Gauge */}
        <div className="lg:col-span-8 bg-slate-900/60 border border-slate-800 rounded-lg p-5 flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                <h2 className="text-base font-bold font-mono text-slate-100 uppercase tracking-tight">
                  Grid Telemetry Performance Matrix
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Continuous diagnostic monitoring of 500 high-voltage transformer units.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right font-mono">
                <span className="text-[10px] text-slate-500 block uppercase">Health Index</span>
                <span className="text-lg font-bold text-blue-400">{metrics.health_score}/100</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-5 text-xs font-mono">
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px] uppercase">Fleet Load</span>
              <span className="text-base font-bold text-slate-200 mt-0.5 block">{metrics.avg_load}%</span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px] uppercase">Oil Temp</span>
              <span className="text-base font-bold text-amber-400 mt-0.5 block">{metrics.avg_oil_temp}°C</span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px] uppercase">Moisture</span>
              <span className="text-base font-bold text-sky-400 mt-0.5 block">{metrics.avg_moisture} ppm</span>
            </div>
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <span className="text-slate-500 block text-[10px] uppercase">Dissolved Gas</span>
              <span className="text-base font-bold text-purple-400 mt-0.5 block">{metrics.avg_dga} ppm</span>
            </div>
          </div>
        </div>

        {/* Gauge & Health Score */}
        <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col items-center justify-center shadow-sm">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
            OVERALL HEALTH INDEX
          </span>
          <GaugeMeter score={metrics.health_score} label="Health Index" max={100} />
          <div className="text-[10px] font-mono text-slate-500 text-center mt-2">
            Weighted Score via Telemetry & Gas Chromatograph
          </div>
        </div>
      </div>

      {/* Active Alerts Panel */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden shadow-sm">
        <div className="px-4 py-3 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-rose-500" />
            <span className="text-xs font-mono font-bold uppercase text-slate-200">ACTIVE SYSTEM ALERTS</span>
          </div>
          <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 text-[10px] font-mono font-bold rounded border border-rose-500/30">
            HIGH PRIORITY
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-slate-800">
          <div className="p-3.5 flex items-start gap-3">
            <div className="w-2 h-2 mt-1.5 rounded-full bg-rose-500 shrink-0 shadow-[0_0_8px_rgba(244,63,94,0.6)]"></div>
            <div>
              <div className="text-xs font-bold font-mono text-slate-200">TR-8821: Critical Temp Alert</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Winding Temp reached 94.2°C. Immediate thermal shutdown advised.</div>
              <div className="text-[9px] font-mono text-slate-500 mt-1">08:42:15 AM - CELL_A2</div>
            </div>
          </div>
          <div className="p-3.5 flex items-start gap-3">
            <div className="w-2 h-2 mt-1.5 rounded-full bg-amber-500 shrink-0 shadow-[0_0_8px_rgba(245,158,11,0.6)]"></div>
            <div>
              <div className="text-xs font-bold font-mono text-slate-200">TR-4402: Moisture Alert</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Moisture content exceeds 25ppm (Current: 28.4ppm). Schedule oil filtration.</div>
              <div className="text-[9px] font-mono text-slate-500 mt-1">07:15:22 AM - CELL_B4</div>
            </div>
          </div>
          <div className="p-3.5 flex items-start gap-3">
            <div className="w-2 h-2 mt-1.5 rounded-full bg-rose-500 shrink-0 shadow-[0_0_8px_rgba(244,63,94,0.6)]"></div>
            <div>
              <div className="text-xs font-bold font-mono text-slate-200">TR-1021: DGA Violation</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Dissolved gas 412ppm. Perform gas chromatography test immediately.</div>
              <div className="text-[9px] font-mono text-slate-500 mt-1">06:05:01 AM - MAIN_GRID</div>
            </div>
          </div>
        </div>
      </div>

      {/* Visual Charts */}
      <ChartsSection chartsData={charts} />
    </div>
  );
};
