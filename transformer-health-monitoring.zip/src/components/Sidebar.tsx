import React from 'react';
import { LayoutDashboard, Cpu, Search, Filter, FileText, Settings } from 'lucide-react';

export type ActiveTab = 'dashboard' | 'predict' | 'search' | 'filter' | 'reports' | 'admin';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const monitoringGroup = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard Overview', icon: LayoutDashboard },
    { id: 'search' as ActiveTab, label: 'Search Unit (ID)', icon: Search },
    { id: 'filter' as ActiveTab, label: 'Live Sensors & Filter', icon: Filter },
  ];

  const analyticsGroup = [
    { id: 'predict' as ActiveTab, label: 'Predictor Model', icon: Cpu },
    { id: 'reports' as ActiveTab, label: 'PDF Report Engine', icon: FileText },
  ];

  const adminGroup = [
    { id: 'admin' as ActiveTab, label: 'Admin Control Panel', icon: Settings },
  ];

  const renderGroup = (title: string, items: typeof monitoringGroup) => (
    <div className="mb-4">
      <div className="text-[10px] uppercase tracking-widest text-slate-500 font-mono px-2 mb-1.5 font-bold">
        {title}
      </div>
      <div className="space-y-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded text-xs font-mono font-medium transition-all ${
                isActive
                  ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <aside className="w-full md:w-64 bg-slate-950 border-r border-slate-800 p-4 flex md:flex-col justify-between transition-colors duration-200 shrink-0">
      <nav className="flex md:flex-col gap-1 w-full overflow-x-auto md:overflow-x-visible pb-2 md:pb-0">
        {renderGroup('Monitoring', monitoringGroup)}
        {renderGroup('Analytics & ML', analyticsGroup)}
        {renderGroup('Administration', adminGroup)}
      </nav>

      <div className="hidden md:block pt-4 border-t border-slate-800 font-mono">
        <div className="bg-blue-950/40 border border-blue-500/30 p-3 rounded-lg">
          <div className="flex justify-between items-center text-xs font-semibold text-blue-300">
            <span>ML Model Accuracy</span>
            <span className="text-emerald-400 font-mono font-bold">98.4%</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-blue-500 h-full rounded-full w-[98.4%]"></div>
          </div>
          <div className="text-[10px] text-slate-500 mt-2">
            Ensemble Architecture (RF, XGB, D-Tree)
          </div>
        </div>
      </div>
    </aside>
  );
};
