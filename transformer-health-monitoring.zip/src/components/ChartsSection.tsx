import React from 'react';
import { DashboardData } from '../types';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend,
  LineChart, Line, ScatterChart, Scatter
} from 'recharts';

interface ChartsSectionProps {
  chartsData: DashboardData['charts'];
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({ chartsData }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
      {/* 1. Pie Chart - Health Distribution */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Health Distribution</span>
          <span className="text-xs font-normal text-slate-400">Total Fleet Target Breakdown</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartsData.health_distribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={4}
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {chartsData.health_distribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Legend verticalAlign="bottom" height={36} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 2. Bar Chart - Cooling Status */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Cooling System Status</span>
          <span className="text-xs font-normal text-slate-400">Cooling Equipment Utilization</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartsData.cooling_distribution}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="status" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} name="Transformer Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 3. Line Chart - Temperature Trend */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Temperature Telemetry Trend</span>
          <span className="text-xs font-normal text-slate-400">Oil vs Winding (°C)</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartsData.temperature_trend}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="Transformer_ID" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={12} domain={[50, 110]} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Legend />
              <Line type="monotone" dataKey="Oil_Temperature_C" stroke="#f59e0b" name="Oil Temp (°C)" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="Winding_Temperature_C" stroke="#ef4444" name="Winding Temp (°C)" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4. Scatter Plot - Load vs Temperature */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Load % vs Oil Temperature</span>
          <span className="text-xs font-normal text-slate-400">Thermal Correlation</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis type="number" dataKey="Load_Percentage" name="Load %" unit="%" stroke="#94a3b8" fontSize={12} />
              <YAxis type="number" dataKey="Oil_Temperature_C" name="Oil Temp" unit="°C" stroke="#94a3b8" fontSize={12} />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Scatter name="Transformers" data={chartsData.load_vs_temperature} fill="#8b5cf6" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 5. Histogram - Oil Temperature */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Oil Temperature Histogram</span>
          <span className="text-xs font-normal text-slate-400">Distribution Range</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartsData.oil_temperature_histogram}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="range" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Bar dataKey="count" fill="#06b6d4" radius={[6, 6, 0, 0]} name="Transformer Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 6. Histogram - Moisture Distribution */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Moisture Distribution (ppm)</span>
          <span className="text-xs font-normal text-slate-400">Moisture PPM Range</span>
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartsData.moisture_histogram}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="range" stroke="#94a3b8" fontSize={11} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Bar dataKey="count" fill="#10b981" radius={[6, 6, 0, 0]} name="Transformer Count" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 7. Feature Importance Chart */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm lg:col-span-2">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center justify-between">
          <span>Feature Importance Analysis (ML Model)</span>
          <span className="text-xs font-normal text-slate-400">Key Health Predictors</span>
        </h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartsData.feature_importance} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis type="number" stroke="#94a3b8" fontSize={12} />
              <YAxis dataKey="feature" type="category" stroke="#94a3b8" fontSize={11} width={130} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '12px', color: '#fff' }}
              />
              <Bar dataKey="importance" fill="#6366f1" radius={[0, 6, 6, 0]} name="Importance Weight" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
