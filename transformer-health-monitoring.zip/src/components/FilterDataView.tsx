import React, { useState, useEffect } from 'react';
import { filterTransformers } from '../services/api';
import { TransformerData } from '../types';
import { HealthBadge } from './HealthBadge';
import { Filter, RefreshCw, Download, FileSpreadsheet } from 'lucide-react';

export const FilterDataView: React.FC = () => {
  const [health, setHealth] = useState<string>('');
  const [cooling, setCooling] = useState<string>('');
  const [minTemp, setMinTemp] = useState<string>('');
  const [maxTemp, setMaxTemp] = useState<string>('');
  const [minLoad, setMinLoad] = useState<string>('');
  const [maxLoad, setMaxLoad] = useState<string>('');
  const [minAge, setMinAge] = useState<string>('');
  const [maxAge, setMaxAge] = useState<string>('');

  const [records, setRecords] = useState<TransformerData[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const pageSize = 15;

  const fetchFiltered = async () => {
    setLoading(true);
    try {
      const payload: any = {};
      if (health) payload.health = health;
      if (cooling) payload.cooling = cooling;
      if (minTemp) payload.min_temp = parseFloat(minTemp);
      if (maxTemp) payload.max_temp = parseFloat(maxTemp);
      if (minLoad) payload.min_load = parseFloat(minLoad);
      if (maxLoad) payload.max_load = parseFloat(maxLoad);
      if (minAge) payload.min_age = parseFloat(minAge);
      if (maxAge) payload.max_age = parseFloat(maxAge);

      const res = await filterTransformers(payload);
      setRecords(res.data || []);
      setPage(1);
    } catch (err) {
      console.error('Filter error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiltered();
  }, []);

  const handleReset = () => {
    setHealth('');
    setCooling('');
    setMinTemp('');
    setMaxTemp('');
    setMinLoad('');
    setMaxLoad('');
    setMinAge('');
    setMaxAge('');
    setTimeout(() => {
      fetchFiltered();
    }, 50);
  };

  const exportFilteredCSV = () => {
    if (!records.length) return;
    const headers = Object.keys(records[0]).join(',');
    const rows = records.map((r) => Object.values(r).map((v) => `"${v}"`).join(','));
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'filtered_transformers.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const totalPages = Math.ceil(records.length / pageSize) || 1;
  const paginatedData = records.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="space-y-6">
      {/* Filters Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Filter Fleet Dataset</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              Reset Filters
            </button>
            <button
              onClick={exportFilteredCSV}
              disabled={!records.length}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-50"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Health Status</label>
            <select
              value={health}
              onChange={(e) => setHealth(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
            >
              <option value="">All Health Statuses</option>
              <option value="Healthy">Healthy</option>
              <option value="Warning">Warning</option>
              <option value="Critical">Critical</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Cooling Status</label>
            <select
              value={cooling}
              onChange={(e) => setCooling(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
            >
              <option value="">All Cooling Modes</option>
              <option value="Normal">Normal</option>
              <option value="Fan Running">Fan Running</option>
              <option value="Oil Pump Running">Oil Pump Running</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Oil Temp (°C)</label>
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="Min"
                value={minTemp}
                onChange={(e) => setMinTemp(e.target.value)}
                className="w-1/2 px-2.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
              />
              <input
                type="number"
                placeholder="Max"
                value={maxTemp}
                onChange={(e) => setMaxTemp(e.target.value)}
                className="w-1/2 px-2.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Load %</label>
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="Min"
                value={minLoad}
                onChange={(e) => setMinLoad(e.target.value)}
                className="w-1/2 px-2.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
              />
              <input
                type="number"
                placeholder="Max"
                value={maxLoad}
                onChange={(e) => setMaxLoad(e.target.value)}
                className="w-1/2 px-2.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={fetchFiltered}
            disabled={loading}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors flex items-center gap-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Apply Filters ({records.length} Found)
          </button>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Matching Transformers ({records.length} total)
          </h3>
          <span className="text-xs text-slate-400">Page {page} of {totalPages}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold uppercase text-[10px]">
              <tr>
                <th className="p-3">ID</th>
                <th className="p-3">Age</th>
                <th className="p-3">Oil Temp</th>
                <th className="p-3">Winding Temp</th>
                <th className="p-3">Load %</th>
                <th className="p-3">Moisture</th>
                <th className="p-3">DGA Gas</th>
                <th className="p-3">Vibration</th>
                <th className="p-3">Cooling</th>
                <th className="p-3">Health Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginatedData.map((row) => (
                <tr key={row.Transformer_ID} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-blue-600 dark:text-blue-400">{row.Transformer_ID}</td>
                  <td className="p-3">{row.Age_Years} yrs</td>
                  <td className="p-3">{row.Oil_Temperature_C}°C</td>
                  <td className="p-3">{row.Winding_Temperature_C}°C</td>
                  <td className="p-3">{row.Load_Percentage}%</td>
                  <td className="p-3">{row.Moisture_ppm} ppm</td>
                  <td className="p-3">{row.Dissolved_Gas_ppm} ppm</td>
                  <td className="p-3">{row.Vibration_mm_s} mm/s</td>
                  <td className="p-3">{row.Cooling_Status}</td>
                  <td className="p-3">
                    <HealthBadge status={row.Health_Status} />
                  </td>
                </tr>
              ))}
              {!paginatedData.length && (
                <tr>
                  <td colSpan={10} className="p-6 text-center text-slate-400">
                    No matching transformer records found for specified criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {totalPages > 1 && (
          <div className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium disabled:opacity-40"
            >
              Previous
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-medium disabled:opacity-40"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
