import React, { useState } from 'react';
import { searchTransformer, generatePdfReportApi } from '../services/api';
import { TransformerData, PredictionResult } from '../types';
import { HealthBadge, AlertBadge } from './HealthBadge';
import { Search, Download, ShieldCheck, Thermometer, Zap, Droplets, Flame, Vibrate } from 'lucide-react';

export const TransformerSearchView: React.FC = () => {
  const [searchId, setSearchId] = useState('T0007');
  const [searching, setSearching] = useState(false);
  const [details, setDetails] = useState<TransformerData | null>(null);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [error, setError] = useState('');
  const [downloading, setDownloading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    setSearching(true);
    setError('');
    setDetails(null);
    setPrediction(null);

    try {
      const res = await searchTransformer(searchId.trim());
      setDetails(res.transformer_details);
      setPrediction(res.prediction);
    } catch (err: any) {
      setError(err.response?.data?.error || `Transformer '${searchId}' not found in database.`);
    } finally {
      setSearching(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!details || !prediction) return;
    setDownloading(true);
    try {
      const res = await generatePdfReportApi(details, prediction);
      if (res.download_url) {
        window.location.href = res.download_url;
      }
    } catch (err) {
      console.error('PDF generation error:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Bar Box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Search Transformer Unit</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Enter Transformer ID (e.g., T0001, T0007, T0015, T0100) to inspect real-time sensor parameters & diagnostic prediction.
        </p>

        <form onSubmit={handleSearch} className="flex gap-2 max-w-lg">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              placeholder="Enter Transformer ID (e.g. T0007)"
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={searching}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors disabled:opacity-50"
          >
            {searching ? 'Searching...' : 'Search'}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs rounded-xl">
            {error}
          </div>
        )}
      </div>

      {/* Details Output */}
      {details && prediction && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-lg space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Transformer ID: <span className="text-blue-600 dark:text-blue-400">{details.Transformer_ID}</span>
                </h3>
                <HealthBadge status={prediction.transformer_health} />
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Age: {details.Age_Years} Years | Cooling: {details.Cooling_Status}
              </p>
            </div>

            <button
              onClick={handleDownloadPDF}
              disabled={downloading}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 font-medium text-xs rounded-xl shadow-md transition-colors disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {downloading ? 'Generating...' : 'Download PDF Report'}
            </button>
          </div>

          {/* Sensor Telemetry Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-amber-500" /> Oil Temp
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Oil_Temperature_C}°C
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-rose-500" /> Winding Temp
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Winding_Temperature_C}°C
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-blue-500" /> Load %
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Load_Percentage}%
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Droplets className="w-3.5 h-3.5 text-sky-500" /> Moisture
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Moisture_ppm} ppm
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-purple-500" /> Dissolved Gas
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Dissolved_Gas_ppm} ppm
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl">
              <span className="text-[11px] text-slate-400 block flex items-center gap-1">
                <Vibrate className="w-3.5 h-3.5 text-rose-500" /> Vibration
              </span>
              <span className="text-sm font-bold text-slate-900 dark:text-white mt-1 block">
                {details.Vibration_mm_s} mm/s
              </span>
            </div>
          </div>

          {/* Diagnostic Recommendation */}
          <div className="p-4 bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-xl">
            <h4 className="text-xs font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5 mb-1">
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              Prescriptive Maintenance Recommendation
            </h4>
            <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
              {prediction.recommendation}
            </p>
          </div>

          {/* Active Alerts */}
          {prediction.alerts && prediction.alerts.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-rose-600 dark:text-rose-400">
                Triggered Threshold Alerts ({prediction.alerts.length})
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {prediction.alerts.map((a, i) => (
                  <AlertBadge key={i} type={a.type} message={a.message} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
