import React, { useState } from 'react';
import { predictHealth, generatePdfReportApi } from '../services/api';
import { TransformerData, PredictionResult } from '../types';
import { HealthBadge, AlertBadge } from './HealthBadge';
import { GaugeMeter } from './GaugeMeter';
import { Cpu, FileText, Download, Sparkles, RefreshCw, AlertCircle } from 'lucide-react';

export const PredictionView: React.FC = () => {
  const [formData, setFormData] = useState<Partial<TransformerData>>({
    Transformer_ID: 'T_CUSTOM_01',
    Age_Years: 12,
    Oil_Temperature_C: 82.5,
    Winding_Temperature_C: 91.0,
    Ambient_Temperature_C: 30,
    Voltage_kV: 11.0,
    Current_A: 380,
    Load_Percentage: 82,
    Oil_Level_Percentage: 92,
    Moisture_ppm: 26.5,
    Dissolved_Gas_ppm: 340,
    Vibration_mm_s: 3.5,
    Partial_Discharge_pC: 58,
    Cooling_Status: 'Normal',
  });

  const [predicting, setPredicting] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [generatingReport, setGeneratingReport] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setPredicting(true);
    setResult(null);

    try {
      const res = await predictHealth(formData);
      setResult(res);
    } catch (err) {
      console.error('Prediction failed:', err);
    } finally {
      setPredicting(false);
    }
  };

  const handleDownloadPDF = async () => {
    if (!result) return;
    setGeneratingReport(true);
    try {
      const res = await generatePdfReportApi(formData, result);
      if (res.download_url) {
        window.location.href = res.download_url;
      }
    } catch (err) {
      console.error('PDF report failed:', err);
    } finally {
      setGeneratingReport(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Predictive Health Analysis</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Input sensor telemetry readings to compute ML health classification, risk score, & prescription.
            </p>
          </div>
        </div>

        <form onSubmit={handlePredict} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Transformer ID</label>
            <input
              type="text"
              name="Transformer_ID"
              value={formData.Transformer_ID}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Age (Years)</label>
            <input
              type="number"
              name="Age_Years"
              value={formData.Age_Years}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Oil Temperature (°C)</label>
            <input
              type="number"
              step="0.1"
              name="Oil_Temperature_C"
              value={formData.Oil_Temperature_C}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Winding Temperature (°C)</label>
            <input
              type="number"
              step="0.1"
              name="Winding_Temperature_C"
              value={formData.Winding_Temperature_C}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Ambient Temperature (°C)</label>
            <input
              type="number"
              step="0.1"
              name="Ambient_Temperature_C"
              value={formData.Ambient_Temperature_C}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Voltage (kV)</label>
            <input
              type="number"
              step="0.1"
              name="Voltage_kV"
              value={formData.Voltage_kV}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Current (A)</label>
            <input
              type="number"
              step="0.1"
              name="Current_A"
              value={formData.Current_A}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Load Percentage (%)</label>
            <input
              type="number"
              step="0.1"
              name="Load_Percentage"
              value={formData.Load_Percentage}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Oil Level (%)</label>
            <input
              type="number"
              step="0.1"
              name="Oil_Level_Percentage"
              value={formData.Oil_Level_Percentage}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Moisture (ppm)</label>
            <input
              type="number"
              step="0.1"
              name="Moisture_ppm"
              value={formData.Moisture_ppm}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Dissolved Gas (ppm)</label>
            <input
              type="number"
              step="0.1"
              name="Dissolved_Gas_ppm"
              value={formData.Dissolved_Gas_ppm}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Vibration (mm/s)</label>
            <input
              type="number"
              step="0.01"
              name="Vibration_mm_s"
              value={formData.Vibration_mm_s}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Partial Discharge (pC)</label>
            <input
              type="number"
              step="0.1"
              name="Partial_Discharge_pC"
              value={formData.Partial_Discharge_pC}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Cooling Status</label>
            <select
              name="Cooling_Status"
              value={formData.Cooling_Status}
              onChange={handleChange}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="Normal">Normal</option>
              <option value="Fan Running">Fan Running</option>
              <option value="Oil Pump Running">Oil Pump Running</option>
            </select>
          </div>

          <div className="md:col-span-2 lg:col-span-3 pt-2">
            <button
              type="submit"
              disabled={predicting}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {predicting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Running Predictive ML Model...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Predict Health & Generate Assessment
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Prediction Output Card */}
      {result && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-lg animate-fadeIn space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <span className="text-xs text-slate-400 font-medium">Diagnostic Target Output</span>
              <div className="flex items-center gap-3 mt-1">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Health Prediction Result</h3>
                <HealthBadge status={result.transformer_health} className="text-sm px-4 py-1.5" />
              </div>
            </div>

            <button
              onClick={handleDownloadPDF}
              disabled={generatingReport}
              className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 dark:hover:bg-white text-white dark:text-slate-900 font-medium text-xs rounded-xl shadow-md transition-colors disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {generatingReport ? 'Generating PDF...' : 'Download PDF Report'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            {/* Confidence metric */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl text-center">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Prediction Confidence</span>
              <div className="text-3xl font-extrabold text-blue-600 dark:text-blue-400 mt-1">
                {result.prediction_confidence}%
              </div>
              <span className="text-[11px] text-slate-400">Model Certainty Score</span>
            </div>

            {/* Risk Score Gauge */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl flex flex-col items-center justify-center">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">Risk Assessment</span>
              <GaugeMeter score={result.risk_score} label="Risk Score" max={100} invertColor={true} />
            </div>

            {/* Recommendation */}
            <div className="bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 p-4 rounded-xl">
              <span className="text-xs font-bold text-blue-900 dark:text-blue-200 flex items-center gap-1.5 mb-1.5">
                <FileText className="w-4 h-4 text-blue-600" />
                Maintenance Recommendation
              </span>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {result.recommendation}
              </p>
            </div>
          </div>

          {/* Active Alert Triggers */}
          {result.alerts && result.alerts.length > 0 && (
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                Triggered Rule Alerts ({result.alerts.length})
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {result.alerts.map((alert, idx) => (
                  <AlertBadge key={idx} type={alert.type} message={alert.message} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
