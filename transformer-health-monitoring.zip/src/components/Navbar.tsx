import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Sun, Moon, LogIn, LogOut, Download, RefreshCw, Shield, Server } from 'lucide-react';

interface NavbarProps {
  onOpenLogin: () => void;
  onRetrain: () => void;
  retraining: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenLogin, onRetrain, retraining }) => {
  const { user, logout, darkMode, toggleDarkMode } = useAuth();

  const handleDownloadDataset = () => {
    window.location.href = '/download?file=dataset.csv';
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-4 lg:px-6 py-2.5 text-slate-200 transition-colors duration-200">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Brand */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-blue-400 font-extrabold tracking-tighter text-lg font-mono">
            <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.8)]"></div>
            XFORM_HEALTH
            <span className="text-[10px] text-slate-500 font-mono font-normal tracking-normal border border-slate-800 px-1.5 py-0.5 rounded bg-slate-900/80">
              v2.4.0-STABLE
            </span>
          </div>

          <div className="hidden lg:flex items-center gap-4 text-xs font-mono border-l border-slate-800 pl-4">
            <div><span className="text-slate-500">REGION:</span> <span className="text-slate-300 font-semibold">NORTH_GRID</span></div>
            <div><span className="text-slate-500">STATUS:</span> <span className="text-emerald-400 font-semibold">LIVE_ONLINE</span></div>
          </div>
        </div>

        {/* Quick Actions & Auth */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick CSV Export */}
          <button
            onClick={handleDownloadDataset}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-semibold rounded bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
            title="Download CSV Dataset"
          >
            <Download className="w-3.5 h-3.5" />
            EXPORT CSV
          </button>

          {/* Quick Retrain */}
          <button
            onClick={onRetrain}
            disabled={retraining}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-blue-900/30 border border-blue-500/40 text-blue-400 hover:bg-blue-900/50 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${retraining ? 'animate-spin' : ''}`} />
            {retraining ? 'TRAINING...' : 'RETRAIN ML'}
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-1.5 text-slate-400 hover:bg-slate-900 rounded border border-slate-800 transition-colors"
            aria-label="Toggle Theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-400" />}
          </button>

          {/* Auth Button */}
          {user ? (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <div className="hidden md:flex flex-col text-right text-xs font-mono">
                <span className="font-semibold text-slate-200 flex items-center gap-1">
                  <Shield className="w-3 h-3 text-blue-400" />
                  {user.username}
                </span>
                <span className="text-slate-500 text-[10px]">{user.role}</span>
              </div>
              <button
                onClick={logout}
                className="p-1.5 text-rose-400 hover:bg-rose-950/40 rounded border border-slate-800 transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenLogin}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-blue-600 hover:bg-blue-500 text-white shadow-sm transition-colors"
            >
              <LogIn className="w-3.5 h-3.5" />
              LOGIN
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
