import React from 'react';

interface GaugeMeterProps {
  score: number;
  label?: string;
  max?: number;
  invertColor?: boolean;
}

export const GaugeMeter: React.FC<GaugeMeterProps> = ({
  score,
  label = 'Health Index',
  max = 100,
  invertColor = false,
}) => {
  const normalized = Math.min(max, Math.max(0, score));
  const percentage = (normalized / max) * 100;
  
  // Angle for SVG arc: 0 to 180 degrees
  const angle = (percentage / 100) * 180;
  const radius = 70;
  const circumference = Math.PI * radius; // Half circle circumference
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  let colorClass = 'stroke-emerald-500';
  let textColor = 'text-emerald-600 dark:text-emerald-400';

  if (!invertColor) {
    if (percentage < 60) {
      colorClass = 'stroke-rose-500';
      textColor = 'text-rose-600 dark:text-rose-400';
    } else if (percentage < 80) {
      colorClass = 'stroke-amber-500';
      textColor = 'text-amber-600 dark:text-amber-400';
    }
  } else {
    // Risk mode: High score is bad
    if (percentage > 50) {
      colorClass = 'stroke-rose-500';
      textColor = 'text-rose-600 dark:text-rose-400';
    } else if (percentage > 25) {
      colorClass = 'stroke-amber-500';
      textColor = 'text-amber-600 dark:text-amber-400';
    }
  }

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <div className="relative w-44 h-24 flex justify-center items-end overflow-hidden">
        <svg className="w-44 h-44 transform -rotate-180" viewBox="0 0 160 160">
          {/* Background track */}
          <path
            d="M 10 80 A 70 70 0 0 1 150 80"
            fill="none"
            stroke="currentColor"
            strokeWidth="14"
            className="text-slate-200 dark:text-slate-800"
            strokeLinecap="round"
          />
          {/* Progress arc */}
          <path
            d="M 10 80 A 70 70 0 0 1 150 80"
            fill="none"
            strokeWidth="14"
            className={`${colorClass} transition-all duration-1000 ease-out`}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute bottom-1 flex flex-col items-center">
          <span className={`text-2xl font-bold tracking-tight ${textColor}`}>
            {score}
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">/{max}</span>
          </span>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</span>
        </div>
      </div>
    </div>
  );
};
