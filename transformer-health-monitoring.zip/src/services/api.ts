import axios from 'axios';
import { DashboardData, PredictionResult, TransformerData, PredictionHistoryRecord } from '../types';

const API_BASE = ''; // Same origin proxy

export const getDashboardData = async (): Promise<DashboardData> => {
  const res = await axios.get(`${API_BASE}/dashboard`);
  return res.data;
};

export const predictHealth = async (data: Partial<TransformerData>): Promise<PredictionResult> => {
  const res = await axios.post(`${API_BASE}/predict`, data);
  return res.data;
};

export const searchTransformer = async (id: string) => {
  const res = await axios.get(`${API_BASE}/search`, { params: { id } });
  return res.data;
};

export const filterTransformers = async (filters: any) => {
  const res = await axios.post(`${API_BASE}/filter`, filters);
  return res.data;
};

export const uploadDatasetFile = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  const res = await axios.post(`${API_BASE}/upload`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
  return res.data;
};

export const retrainModelApi = async () => {
  const res = await axios.post(`${API_BASE}/train`);
  return res.data;
};

export const generatePdfReportApi = async (transformerData: Partial<TransformerData>, predictionResult?: PredictionResult) => {
  const res = await axios.post(`${API_BASE}/report`, {
    transformer_data: transformerData,
    prediction_result: predictionResult
  });
  return res.data;
};

export const getPredictionHistoryApi = async (): Promise<PredictionHistoryRecord[]> => {
  const res = await axios.get(`${API_BASE}/api/history`);
  return res.data;
};
