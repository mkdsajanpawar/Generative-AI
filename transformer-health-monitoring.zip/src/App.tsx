import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { PredictionView } from './components/PredictionView';
import { TransformerSearchView } from './components/TransformerSearchView';
import { FilterDataView } from './components/FilterDataView';
import { ReportsView } from './components/ReportsView';
import { AdminPanel } from './components/AdminPanel';
import { LoginModal } from './components/LoginModal';
import { getDashboardData, retrainModelApi } from './services/api';
import { DashboardData } from './types';

export function AppContent() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [loginOpen, setLoginOpen] = useState(false);
  const [retraining, setRetraining] = useState(false);

  const fetchDashboard = async () => {
    setLoading(true);
    try {
      const data = await getDashboardData();
      setDashboardData(data);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  const handleRetrain = async () => {
    setRetraining(true);
    try {
      await retrainModelApi();
      await fetchDashboard();
    } catch (err) {
      console.error('Retrain error:', err);
    } finally {
      setRetraining(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 flex flex-col font-sans transition-colors duration-200">
      <Navbar
        onOpenLogin={() => setLoginOpen(true)}
        onRetrain={handleRetrain}
        retraining={retraining}
      />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView data={dashboardData} loading={loading} onRefresh={fetchDashboard} />
          )}

          {activeTab === 'predict' && <PredictionView />}

          {activeTab === 'search' && <TransformerSearchView />}

          {activeTab === 'filter' && <FilterDataView />}

          {activeTab === 'reports' && <ReportsView />}

          {activeTab === 'admin' && (
            <AdminPanel
              modelStats={dashboardData?.model_stats || null}
              onModelRetrained={fetchDashboard}
              onOpenLogin={() => setLoginOpen(true)}
            />
          )}
        </main>
      </div>

      <footer className="h-8 bg-slate-950 border-t border-slate-800 flex items-center px-6 justify-between text-[10px] text-slate-500 font-mono">
        <div className="flex gap-4">
          <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div> DB: SQLite Connected</span>
          <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div> API: Flask Active</span>
          <span className="hidden sm:flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div> ENGINE: Ensemble ML</span>
        </div>
        <div className="hidden sm:block">GRID_REGION: NORTH_1</div>
      </footer>

      <LoginModal isOpen={loginOpen} onClose={() => setLoginOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
