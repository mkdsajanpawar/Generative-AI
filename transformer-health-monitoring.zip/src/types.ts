export type HealthStatus = 'Healthy' | 'Warning' | 'Critical';

export interface TransformerData {
  Transformer_ID: string;
  Age_Years: number;
  Oil_Temperature_C: number;
  Winding_Temperature_C: number;
  Ambient_Temperature_C: number;
  Voltage_kV: number;
  Current_A: number;
  Load_Percentage: number;
  Oil_Level_Percentage: number;
  Moisture_ppm: number;
  Dissolved_Gas_ppm: number;
  Vibration_mm_s: number;
  Partial_Discharge_pC: number;
  Cooling_Status: 'Normal' | 'Fan Running' | 'Oil Pump Running';
  Health_Status?: HealthStatus;
  Last_Updated?: string;
}

export interface AlertItem {
  type: string;
  message: string;
}

export interface PredictionResult {
  transformer_health: HealthStatus;
  prediction_confidence: number;
  risk_score: number;
  recommendation: string;
  alerts: AlertItem[];
  timestamp?: string;
}

export interface DashboardMetrics {
  total_transformers: number;
  healthy: number;
  warning: number;
  critical: number;
  avg_load: number;
  avg_oil_temp: number;
  avg_moisture: number;
  avg_dga: number;
  avg_vibration: number;
  health_score: number;
}

export interface ModelComparison {
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  confusion_matrix: number[][];
}

export interface ModelStats {
  best_model: string;
  best_accuracy: number;
  target_classes: string[];
  cooling_classes: string[];
  models_comparison: Record<string, ModelComparison>;
  feature_importances: Array<{ feature: string; importance: number }>;
  total_records: number;
}

export interface DashboardData {
  metrics: DashboardMetrics;
  charts: {
    health_distribution: Array<{ name: string; value: number; color: string }>;
    cooling_distribution: Array<{ status: string; count: number }>;
    temperature_trend: Array<{ Transformer_ID: string; Oil_Temperature_C: number; Winding_Temperature_C: number; Ambient_Temperature_C: number }>;
    load_vs_temperature: Array<{ Transformer_ID: string; Load_Percentage: number; Oil_Temperature_C: number; Health_Status: string }>;
    oil_temperature_histogram: Array<{ range: string; count: number }>;
    moisture_histogram: Array<{ range: string; count: number }>;
    feature_importance: Array<{ feature: string; importance: number }>;
  };
  model_stats: ModelStats;
}

export interface PredictionHistoryRecord {
  id: number;
  transformer_id: string;
  input_data: TransformerData;
  predicted_status: HealthStatus;
  confidence: number;
  risk_score: number;
  recommendation: string;
  timestamp: string;
}

export interface User {
  username: string;
  role: string;
  token: string;
}
