# Transformer Health Monitoring System

An AI-Powered Transformer Health Monitoring & Diagnostic Web Application built with React, Tailwind CSS, Recharts, Python Flask, SQLite, and Scikit-Learn machine learning algorithms.

## Features
- **Machine Learning Engine**: Preprocesses 500-record transformer telemetry dataset, trains Random Forest, Decision Tree, Gradient Boosting, XGBoost, and Logistic Regression classifiers, and automatically deploys the highest-accuracy model.
- **Interactive Dashboard**: Real-time KPI cards, health index gauge, pie charts, bar charts, temperature trends, load vs temperature scatter plots, histograms, and feature importances.
- **Predictive Diagnostics**: Input sensor telemetry (Oil Temp, Winding Temp, Moisture, DGA, Vibration, Partial Discharge, etc.) to get instant Health Status, Confidence %, Risk Score, and Prescriptive Maintenance Plan.
- **Alert Rules Engine**: Triggers instant high temperature, moisture, gas, vibration, and insulation breakdown warning alerts.
- **PDF Report Generation**: Download professional industrial PDF assessment reports.
- **Search & Filter**: Search transformer units by ID or apply multi-parameter filters (Health, Cooling Mode, Temp, Load, Age) with CSV export.
- **Admin Control**: Dataset upload, retrain algorithms, and inspect confusion matrix.

## Commands to Run Project

### 1. Install Dependencies
```bash
# Node dependencies
npm install

# Python dependencies
pip install -r requirements.txt
```

### 2. Run Development Server
```bash
npm run dev
```

### 3. Build & Production Start
```bash
npm run build
npm start
```
