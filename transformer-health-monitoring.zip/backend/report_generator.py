import os
import json
from fpdf import FPDF

REPORTS_DIR = os.path.join(os.path.dirname(__file__), '..', 'reports')
os.makedirs(REPORTS_DIR, exist_ok=True)

class TransformerPDFReport(FPDF):
    def header(self):
        self.set_fill_color(30, 58, 138) # Dark blue header
        self.rect(0, 0, 210, 25, 'F')
        self.set_text_color(255, 255, 255)
        self.set_font('Arial', 'B', 15)
        self.cell(0, 8, 'TRANSFORMER HEALTH ASSESSMENT REPORT', 0, 1, 'C')
        self.set_font('Arial', 'I', 9)
        self.cell(0, 5, 'AI-Powered Diagnostic & Predictive Maintenance Insights', 0, 1, 'C')
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(128, 128, 128)
        self.cell(0, 10, f'Page {self.page_no()} | Confidential - Industrial Grid Diagnostics', 0, 0, 'C')

def generate_pdf_report(transformer_data, prediction_result):
    pdf = TransformerPDFReport()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    # Title Sub-header
    transformer_id = transformer_data.get('Transformer_ID', 'N/A')
    pdf.set_font('Arial', 'B', 12)
    pdf.set_text_color(30, 41, 59)
    pdf.cell(0, 7, f"Transformer Unit ID: {transformer_id}", 0, 1, 'L')
    pdf.set_font('Arial', '', 10)
    pdf.cell(0, 5, f"Assessment Date: {prediction_result.get('timestamp', 'Recent Diagnostic Session')}", 0, 1, 'L')
    pdf.ln(4)

    # Health Summary Box
    status = prediction_result.get('transformer_health', 'Healthy')
    confidence = prediction_result.get('prediction_confidence', 95.0)
    risk_score = prediction_result.get('risk_score', 20.0)

    if status == 'Healthy':
        pdf.set_fill_color(220, 252, 231)
        pdf.set_text_color(22, 101, 52)
    elif status == 'Warning':
        pdf.set_fill_color(254, 240, 138)
        pdf.set_text_color(133, 77, 14)
    else:
        pdf.set_fill_color(254, 226, 226)
        pdf.set_text_color(153, 27, 27)

    pdf.rect(10, pdf.get_y(), 190, 20, 'F')
    pdf.set_xy(15, pdf.get_y() + 3)
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(60, 6, f"Health Status: {status.upper()}", 0, 0)
    pdf.cell(60, 6, f"Confidence: {confidence}%", 0, 0)
    pdf.cell(60, 6, f"Risk Score: {risk_score}/100", 0, 1)
    pdf.ln(10)

    # Sensor Values Table
    pdf.set_font('Arial', 'B', 11)
    pdf.set_text_color(30, 41, 59)
    pdf.cell(0, 8, "Operational Telemetry & Sensor Readings", 0, 1, 'L')
    
    pdf.set_font('Arial', 'B', 9)
    pdf.set_fill_color(241, 245, 249)
    pdf.cell(95, 7, "Parameter Name", 1, 0, 'L', True)
    pdf.cell(95, 7, "Recorded Value", 1, 1, 'L', True)

    pdf.set_font('Arial', '', 9)
    sensor_mappings = [
        ("Age (Years)", transformer_data.get('Age_Years', 'N/A')),
        ("Oil Temperature (°C)", f"{transformer_data.get('Oil_Temperature_C', 'N/A')} °C"),
        ("Winding Temperature (°C)", f"{transformer_data.get('Winding_Temperature_C', 'N/A')} °C"),
        ("Ambient Temperature (°C)", f"{transformer_data.get('Ambient_Temperature_C', 'N/A')} °C"),
        ("Voltage (kV)", f"{transformer_data.get('Voltage_kV', 'N/A')} kV"),
        ("Current (A)", f"{transformer_data.get('Current_A', 'N/A')} A"),
        ("Load Percentage (%)", f"{transformer_data.get('Load_Percentage', 'N/A')}%"),
        ("Oil Level (%)", f"{transformer_data.get('Oil_Level_Percentage', 'N/A')}%"),
        ("Moisture (ppm)", f"{transformer_data.get('Moisture_ppm', 'N/A')} ppm"),
        ("Dissolved Gas (ppm)", f"{transformer_data.get('Dissolved_Gas_ppm', 'N/A')} ppm"),
        ("Vibration (mm/s)", f"{transformer_data.get('Vibration_mm_s', 'N/A')} mm/s"),
        ("Partial Discharge (pC)", f"{transformer_data.get('Partial_Discharge_pC', 'N/A')} pC"),
        ("Cooling Status", transformer_data.get('Cooling_Status', 'Normal'))
    ]

    for param, val in sensor_mappings:
        pdf.cell(95, 6, param, 1, 0, 'L')
        pdf.cell(95, 6, str(val), 1, 1, 'L')

    pdf.ln(6)

    # Maintenance Recommendation Section
    pdf.set_font('Arial', 'B', 11)
    pdf.cell(0, 8, "Prescriptive Maintenance Action Plan", 0, 1, 'L')
    pdf.set_font('Arial', '', 10)
    pdf.set_fill_color(248, 250, 252)
    pdf.multi_cell(190, 6, prediction_result.get('recommendation', 'Routine monitoring.'), 1, 'L', True)

    pdf.ln(4)

    # Active Sensor Alerts
    alerts = prediction_result.get('alerts', [])
    if alerts:
        pdf.set_font('Arial', 'B', 11)
        pdf.set_text_color(225, 29, 72)
        pdf.cell(0, 8, f"Active Triggered Threshold Alerts ({len(alerts)})", 0, 1, 'L')
        pdf.set_font('Arial', '', 9)
        pdf.set_text_color(30, 41, 59)
        for alert in alerts:
            pdf.cell(5, 5, "•", 0, 0)
            pdf.cell(185, 5, f"{alert['type']}: {alert['message']}", 0, 1)

    output_filename = f"report_{transformer_id}.pdf"
    output_path = os.path.join(REPORTS_DIR, output_filename)
    pdf.output(output_path)
    return output_path, output_filename
