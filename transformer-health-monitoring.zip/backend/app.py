import os
import json
import pandas as pd
from flask import Flask, request, jsonify, send_file
from database import init_db, load_csv_into_db, get_all_transformers, get_transformer_by_id, save_prediction, get_prediction_history
from ml_engine import train_and_compare_models, predict_health, METRICS_PATH, check_alerts
from report_generator import generate_pdf_report, REPORTS_DIR

app = Flask(__name__)

DATASET_CSV = os.path.join(os.path.dirname(__file__), '..', 'dataset', 'transformer_health_dataset_500_records.csv')

# Initialize DB on start
init_db()
if os.path.exists(DATASET_CSV):
    load_csv_into_db(DATASET_CSV)

# Ensure ML model is trained
if not os.path.exists(METRICS_PATH) and os.path.exists(DATASET_CSV):
    try:
        train_and_compare_models(DATASET_CSV)
    except Exception as e:
        print("Initial model training failed:", e)

@app.route('/upload', methods=['POST'])
def upload_dataset():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    filepath = os.path.join(os.path.dirname(__file__), '..', 'dataset', file.filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)

    # Update database
    success, msg = load_csv_into_db(filepath)
    if not success:
        return jsonify({"error": msg}), 400

    # Retrain model
    try:
        train_summary = train_and_compare_models(filepath)
        return jsonify({"message": "Dataset uploaded and database updated successfully", "train_summary": train_summary})
    except Exception as e:
        return jsonify({"message": "Dataset loaded into DB but model retraining failed", "error": str(e)})

@app.route('/train', methods=['POST'])
def retrain_model():
    try:
        summary = train_and_compare_models(DATASET_CSV)
        return jsonify({"status": "success", "summary": summary})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json or {}
    transformer_id = data.get('Transformer_ID', 'CUSTOM_PRED')

    try:
        result = predict_health(data)
        save_prediction(
            transformer_id=transformer_id,
            input_data=data,
            predicted_status=result['transformer_health'],
            confidence=result['prediction_confidence'],
            risk_score=result['risk_score'],
            recommendation=result['recommendation']
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/dashboard', methods=['GET'])
def get_dashboard_data():
    transformers = get_all_transformers()
    if not transformers:
        return jsonify({"error": "No transformer records found"}), 44

    df = pd.DataFrame(transformers)

    total_transformers = len(df)
    healthy_count = int((df['Health_Status'] == 'Healthy').sum())
    warning_count = int((df['Health_Status'] == 'Warning').sum())
    critical_count = int((df['Health_Status'] == 'Critical').sum())

    avg_load = round(float(df['Load_Percentage'].mean()), 1)
    avg_oil_temp = round(float(df['Oil_Temperature_C'].mean()), 1)
    avg_moisture = round(float(df['Moisture_ppm'].mean()), 1)
    avg_dga = round(float(df['Dissolved_Gas_ppm'].mean()), 1)
    avg_vibration = round(float(df['Vibration_mm_s'].mean()), 2)

    health_distribution = [
        {"name": "Healthy", "value": healthy_count, "color": "#10B981"},
        {"name": "Warning", "value": warning_count, "color": "#F59E0B"},
        {"name": "Critical", "value": critical_count, "color": "#EF4444"}
    ]

    cooling_counts = df['Cooling_Status'].value_counts().to_dict()
    cooling_distribution = [{"status": k, "count": int(v)} for k, v in cooling_counts.items()]

    # Time/Index Temperature trend sample
    temp_trend = df[['Transformer_ID', 'Oil_Temperature_C', 'Winding_Temperature_C', 'Ambient_Temperature_C']].head(20).to_dict(orient='records')

    # Load vs Temp scatter sample
    load_vs_temp = df[['Transformer_ID', 'Load_Percentage', 'Oil_Temperature_C', 'Health_Status']].head(50).to_dict(orient='records')

    # Histograms
    oil_temp_bins = pd.cut(df['Oil_Temperature_C'], bins=5).value_counts(sort=False).to_dict()
    oil_temp_hist = [{"range": f"{int(k.left)}-{int(k.right)}°C", "count": int(v)} for k, v in oil_temp_bins.items()]

    moisture_bins = pd.cut(df['Moisture_ppm'], bins=5).value_counts(sort=False).to_dict()
    moisture_hist = [{"range": f"{int(k.left)}-{int(k.right)} ppm", "count": int(v)} for k, v in moisture_bins.items()]

    # Load model feature importances
    feat_importances = []
    model_stats = {}
    if os.path.exists(METRICS_PATH):
        try:
            with open(METRICS_PATH, 'r') as f:
                model_meta = json.load(f)
                feat_importances = model_meta.get('feature_importances', [])
                model_stats = model_meta
        except:
            pass

    # Overall Health Index score (0 - 100)
    health_score = round(100 - (warning_count * 0.3 + critical_count * 0.8) / total_transformers * 100, 1)

    return jsonify({
        "metrics": {
            "total_transformers": total_transformers,
            "healthy": healthy_count,
            "warning": warning_count,
            "critical": critical_count,
            "avg_load": avg_load,
            "avg_oil_temp": avg_oil_temp,
            "avg_moisture": avg_moisture,
            "avg_dga": avg_dga,
            "avg_vibration": avg_vibration,
            "health_score": health_score
        },
        "charts": {
            "health_distribution": health_distribution,
            "cooling_distribution": cooling_distribution,
            "temperature_trend": temp_trend,
            "load_vs_temperature": load_vs_temp,
            "oil_temperature_histogram": oil_temp_hist,
            "moisture_histogram": moisture_hist,
            "feature_importance": feat_importances
        },
        "model_stats": model_stats
    })

@app.route('/search', methods=['GET'])
def search_transformer():
    tid = request.args.get('id', '').strip()
    if not tid:
        return jsonify({"error": "Transformer ID parameter required"}), 400

    row = get_transformer_by_id(tid)
    if not row:
        return jsonify({"error": f"Transformer with ID '{tid}' not found"}), 404

    pred_res = predict_health(row)
    return jsonify({
        "transformer_details": row,
        "prediction": pred_res,
        "alerts": check_alerts(row)
    })

@app.route('/filter', methods=['POST'])
def filter_transformers():
    filters = request.json or {}
    health = filters.get('health')
    cooling = filters.get('cooling')
    min_temp = filters.get('min_temp')
    max_temp = filters.get('max_temp')
    min_load = filters.get('min_load')
    max_load = filters.get('max_load')
    min_age = filters.get('min_age')
    max_age = filters.get('max_age')

    transformers = get_all_transformers()
    df = pd.DataFrame(transformers)

    if health:
        df = df[df['Health_Status'].str.lower() == str(health).lower()]
    if cooling:
        df = df[df['Cooling_Status'].str.lower() == str(cooling).lower()]
    if min_temp is not None:
        df = df[df['Oil_Temperature_C'] >= float(min_temp)]
    if max_temp is not None:
        df = df[df['Oil_Temperature_C'] <= float(max_temp)]
    if min_load is not None:
        df = df[df['Load_Percentage'] >= float(min_load)]
    if max_load is not None:
        df = df[df['Load_Percentage'] <= float(max_load)]
    if min_age is not None:
        df = df[df['Age_Years'] >= float(min_age)]
    if max_age is not None:
        df = df[df['Age_Years'] <= float(max_age)]

    return jsonify({"count": len(df), "data": df.to_dict(orient='records')})

@app.route('/report', methods=['POST'])
def generate_report():
    data = request.json or {}
    transformer_data = data.get('transformer_data', {})
    if not transformer_data and 'Transformer_ID' in data:
        transformer_data = data

    prediction_result = data.get('prediction_result')
    if not prediction_result:
        prediction_result = predict_health(transformer_data)

    output_path, filename = generate_pdf_report(transformer_data, prediction_result)
    return jsonify({
        "message": "Report generated successfully",
        "download_url": f"/download?file={filename}"
    })

@app.route('/download', methods=['GET'])
def download_file():
    filename = request.args.get('file', '')
    if filename.endswith('.pdf'):
        filepath = os.path.join(REPORTS_DIR, filename)
        if os.path.exists(filepath):
            return send_file(filepath, as_attachment=True)
    elif filename == 'dataset.csv':
        if os.path.exists(DATASET_CSV):
            return send_file(DATASET_CSV, as_attachment=True)

    return jsonify({"error": "File not found"}), 404

@app.route('/api/history', methods=['GET'])
def history():
    records = get_prediction_history(100)
    return jsonify(records)

@app.route('/api/login', methods=['POST'])
def login():
    creds = request.json or {}
    username = creds.get('username')
    password = creds.get('password')

    # Demo authentication logic
    if username and password:
        return jsonify({
            "token": "demo-jwt-token-auth",
            "username": username,
            "role": "Admin" if username == "admin" else "Engineer"
        })
    return jsonify({"error": "Invalid username or password"}), 401

if __name__ == '__main__':
    port = int(os.environ.get('FLASK_PORT', 5000))
    app.run(host='0.0.0.0', port=port)
