import sqlite3
import os
import pandas as pd
import json

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'transformer_monitoring.db')

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Transformers main table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS transformers (
        Transformer_ID TEXT PRIMARY KEY,
        Age_Years REAL,
        Oil_Temperature_C REAL,
        Winding_Temperature_C REAL,
        Ambient_Temperature_C REAL,
        Voltage_kV REAL,
        Current_A REAL,
        Load_Percentage REAL,
        Oil_Level_Percentage REAL,
        Moisture_ppm REAL,
        Dissolved_Gas_ppm REAL,
        Vibration_mm_s REAL,
        Partial_Discharge_pC REAL,
        Cooling_Status TEXT,
        Health_Status TEXT,
        Last_Updated DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Predictions history log table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS prediction_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transformer_id TEXT,
        input_data TEXT,
        predicted_status TEXT,
        confidence REAL,
        risk_score REAL,
        recommendation TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # Model metrics & train state
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS model_meta (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    ''')

    conn.commit()
    conn.close()

def load_csv_into_db(csv_path):
    init_db()
    if not os.path.exists(csv_path):
        return False, "CSV file not found"
    
    df = pd.read_csv(csv_path)
    conn = sqlite3.connect(DB_PATH)
    # Replace contents of transformers table
    df.to_sql('transformers', conn, if_exists='replace', index=False)
    conn.commit()
    conn.close()
    return True, f"Loaded {len(df)} records into SQLite database"

def get_all_transformers():
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transformers")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_transformer_by_id(transformer_id):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transformers WHERE Transformer_ID = ?", (transformer_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def save_prediction(transformer_id, input_data, predicted_status, confidence, risk_score, recommendation):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO prediction_history (transformer_id, input_data, predicted_status, confidence, risk_score, recommendation)
    VALUES (?, ?, ?, ?, ?, ?)
    ''', (transformer_id, json.dumps(input_data), predicted_status, confidence, risk_score, recommendation))
    conn.commit()
    conn.close()

def get_prediction_history(limit=50):
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM prediction_history ORDER BY id DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    res = []
    for row in rows:
        d = dict(row)
        try:
            d['input_data'] = json.loads(d['input_data'])
        except:
            pass
        res.append(d)
    return res

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully.")
