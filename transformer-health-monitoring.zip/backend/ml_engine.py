import os
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix

MODELS_DIR = os.path.join(os.path.dirname(__file__), '..', 'models')
os.makedirs(MODELS_DIR, exist_ok=True)

MODEL_PATH = os.path.join(MODELS_DIR, 'best_transformer_model.joblib')
SCALER_PATH = os.path.join(MODELS_DIR, 'scaler.joblib')
ENCODER_PATH = os.path.join(MODELS_DIR, 'cooling_encoder.joblib')
TARGET_ENCODER_PATH = os.path.join(MODELS_DIR, 'target_encoder.joblib')
METRICS_PATH = os.path.join(MODELS_DIR, 'model_metrics.json')

FEATURE_COLS = [
    'Age_Years', 'Oil_Temperature_C', 'Winding_Temperature_C', 'Ambient_Temperature_C',
    'Voltage_kV', 'Current_A', 'Load_Percentage', 'Oil_Level_Percentage',
    'Moisture_ppm', 'Dissolved_Gas_ppm', 'Vibration_mm_s', 'Partial_Discharge_pC',
    'Cooling_Status'
]

def check_alerts(data):
    """
    Alert Rules:
    - Oil Temperature > 80°C -> High Temperature Alert
    - Winding Temperature > 90°C -> Critical Temperature Alert
    - Moisture > 25 ppm -> Moisture Alert
    - DGA > 400 ppm -> Gas Alert
    - Vibration > 4 mm/s -> Mechanical Fault Alert
    - Partial Discharge > 70 pC -> Insulation Alert
    """
    alerts = []
    if float(data.get('Oil_Temperature_C', 0)) > 80:
        alerts.append({"type": "High Temperature Alert", "message": "Oil Temperature exceeded 80°C limit"})
    if float(data.get('Winding_Temperature_C', 0)) > 90:
        alerts.append({"type": "Critical Temperature Alert", "message": "Winding Temperature exceeded 90°C critical threshold"})
    if float(data.get('Moisture_ppm', 0)) > 25:
        alerts.append({"type": "Moisture Alert", "message": "Moisture level > 25 ppm indicates potential degradation"})
    if float(data.get('Dissolved_Gas_ppm', 0)) > 400:
        alerts.append({"type": "Gas Alert", "message": "Dissolved Gas > 400 ppm indicates internal arcing/overheating"})
    if float(data.get('Vibration_mm_s', 0)) > 4.0:
        alerts.append({"type": "Mechanical Fault Alert", "message": "Vibration > 4 mm/s signals mechanical anomaly"})
    if float(data.get('Partial_Discharge_pC', 0)) > 70:
        alerts.append({"type": "Insulation Alert", "message": "Partial Discharge > 70 pC indicates insulation breakdown"})
    return alerts

def get_maintenance_recommendation(status):
    """
    Maintenance Recommendation Logic:
    - Healthy: Continue routine inspection.
    - Warning: Inspect transformer within one week. Check oil quality. Inspect cooling system.
    - Critical: Immediate shutdown recommended. Perform DGA test. Inspect insulation. Inspect winding. Replace oil if necessary.
    """
    if status == 'Healthy':
        return "Continue routine inspection."
    elif status == 'Warning':
        return "Inspect transformer within one week. Check oil quality. Inspect cooling system."
    else:
        return "Immediate shutdown recommended. Perform DGA test. Inspect insulation. Inspect winding. Replace oil if necessary."

def calculate_risk_score(data):
    """Calculates an intuitive 0-100 Risk Score based on key sensor parameters."""
    score = 0.0
    oil_temp = float(data.get('Oil_Temperature_C', 60))
    wind_temp = float(data.get('Winding_Temperature_C', 70))
    moisture = float(data.get('Moisture_ppm', 10))
    dga = float(data.get('Dissolved_Gas_ppm', 150))
    vib = float(data.get('Vibration_mm_s', 2))
    pd = float(data.get('Partial_Discharge_pC', 20))
    age = float(data.get('Age_Years', 5))

    # Weighted risk elements
    score += min(30, max(0, (oil_temp - 60) * 1.0))
    score += min(30, max(0, (wind_temp - 70) * 1.0))
    score += min(20, max(0, (moisture - 10) * 0.8))
    score += min(25, max(0, (dga - 150) * 0.06))
    score += min(15, max(0, (vib - 2.0) * 5.0))
    score += min(15, max(0, (pd - 20) * 0.25))
    score += min(10, max(0, age * 0.3))

    return round(min(100.0, max(0.0, score)), 1)

def train_and_compare_models(csv_path):
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV dataset not found at {csv_path}")

    df = pd.read_csv(csv_path)

    # Clean / Handle missing values
    df = df.dropna(subset=['Health_Status'])
    for col in FEATURE_COLS:
        if col != 'Cooling_Status' and col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(df[col].median())

    if 'Cooling_Status' in df.columns:
        df['Cooling_Status'] = df['Cooling_Status'].fillna('Normal').astype(str)

    # Encode categorical features
    cooling_encoder = LabelEncoder()
    df['Cooling_Status_Enc'] = cooling_encoder.fit_transform(df['Cooling_Status'])

    target_encoder = LabelEncoder()
    df['Target_Enc'] = target_encoder.fit_transform(df['Health_Status'])

    feature_columns_processed = [
        'Age_Years', 'Oil_Temperature_C', 'Winding_Temperature_C', 'Ambient_Temperature_C',
        'Voltage_kV', 'Current_A', 'Load_Percentage', 'Oil_Level_Percentage',
        'Moisture_ppm', 'Dissolved_Gas_ppm', 'Vibration_mm_s', 'Partial_Discharge_pC',
        'Cooling_Status_Enc'
    ]

    X = df[feature_columns_processed]
    y = df['Target_Enc']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    classifiers = {
        "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42),
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42)
    }

    # Try importing XGBoost
    try:
        from xgboost import XGBClassifier
        classifiers["XGBoost"] = XGBClassifier(eval_metric='mlogloss', random_state=42)
    except Exception as e:
        print("XGBoost not available, skipping XGBoost classifier:", e)

    results = {}
    best_model_name = None
    best_accuracy = -1.0
    best_model_obj = None

    for name, clf in classifiers.items():
        clf.fit(X_train_scaled, y_train)
        y_pred = clf.predict(X_test_scaled)

        acc = accuracy_score(y_test, y_pred)
        precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='weighted')
        cm = confusion_matrix(y_test, y_pred).tolist()

        results[name] = {
            "accuracy": round(float(acc), 4),
            "precision": round(float(precision), 4),
            "recall": round(float(recall), 4),
            "f1_score": round(float(f1), 4),
            "confusion_matrix": cm
        }

        if acc > best_accuracy:
            best_accuracy = acc
            best_model_name = name
            best_model_obj = clf

    # Calculate Feature Importances from best model or Random Forest
    rf_model = classifiers["Random Forest"]
    importances = rf_model.feature_importances_
    raw_feature_names = [
        'Age', 'Oil Temp', 'Winding Temp', 'Ambient Temp',
        'Voltage', 'Current', 'Load %', 'Oil Level',
        'Moisture', 'Dissolved Gas', 'Vibration', 'Partial Discharge',
        'Cooling Status'
    ]
    feat_imp = [
        {"feature": name, "importance": round(float(imp), 4)}
        for name, imp in sorted(zip(raw_feature_names, importances), key=lambda x: x[1], reverse=True)
    ]

    # Save best model and artifacts
    joblib.dump(best_model_obj, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    joblib.dump(cooling_encoder, ENCODER_PATH)
    joblib.dump(target_encoder, TARGET_ENCODER_PATH)

    summary = {
        "best_model": best_model_name,
        "best_accuracy": round(float(best_accuracy), 4),
        "target_classes": target_encoder.classes_.tolist(),
        "cooling_classes": cooling_encoder.classes_.tolist(),
        "models_comparison": results,
        "feature_importances": feat_imp,
        "total_records": len(df)
    }

    with open(METRICS_PATH, 'w') as f:
        json.dump(summary, f, indent=2)

    return summary

def predict_health(data):
    """
    Predicts transformer health for input sensor data.
    """
    if not (os.path.exists(MODEL_PATH) and os.path.exists(SCALER_PATH)):
        # Train model if not trained yet
        dataset_csv = os.path.join(os.path.dirname(__file__), '..', 'dataset', 'transformer_health_dataset_500_records.csv')
        train_and_compare_models(dataset_csv)

    clf = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    cooling_encoder = joblib.load(ENCODER_PATH)
    target_encoder = joblib.load(TARGET_ENCODER_PATH)

    # Encode cooling status safely
    cooling_val = str(data.get('Cooling_Status', 'Normal'))
    if cooling_val in cooling_encoder.classes_:
        cooling_enc = cooling_encoder.transform([cooling_val])[0]
    else:
        cooling_enc = 0

    input_vector = [
        float(data.get('Age_Years', 5)),
        float(data.get('Oil_Temperature_C', 70)),
        float(data.get('Winding_Temperature_C', 80)),
        float(data.get('Ambient_Temperature_C', 25)),
        float(data.get('Voltage_kV', 11.0)),
        float(data.get('Current_A', 250)),
        float(data.get('Load_Percentage', 60)),
        float(data.get('Oil_Level_Percentage', 95)),
        float(data.get('Moisture_ppm', 15)),
        float(data.get('Dissolved_Gas_ppm', 250)),
        float(data.get('Vibration_mm_s', 2.5)),
        float(data.get('Partial_Discharge_pC', 35)),
        cooling_enc
    ]

    input_scaled = scaler.transform([input_vector])
    pred_class_enc = clf.predict(input_scaled)[0]
    predicted_status = target_encoder.inverse_transform([pred_class_enc])[0]

    # Calculate confidence probabilities
    if hasattr(clf, "predict_proba"):
        probs = clf.predict_proba(input_scaled)[0]
        confidence = round(float(np.max(probs)) * 100, 1)
    else:
        confidence = 92.5

    risk_score = calculate_risk_score(data)
    recommendation = get_maintenance_recommendation(predicted_status)
    alerts = check_alerts(data)

    return {
        "transformer_health": predicted_status,
        "prediction_confidence": confidence,
        "risk_score": risk_score,
        "recommendation": recommendation,
        "alerts": alerts
    }

if __name__ == '__main__':
    dataset_csv = os.path.join(os.path.dirname(__file__), '..', 'dataset', 'transformer_health_dataset_500_records.csv')
    res = train_and_compare_models(dataset_csv)
    print("Model Training Completed Successfully:")
    print("Best Model:", res["best_model"], "with accuracy:", res["best_accuracy"])
